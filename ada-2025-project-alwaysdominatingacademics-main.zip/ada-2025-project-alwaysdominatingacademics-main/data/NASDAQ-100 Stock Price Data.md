## Dataset

The original stock dataset (~2.5 GB) is too large to be included in this repository.

You can download it from Kaggle:
👉 [NASDAQ 100 Stock Price Data](https://www.kaggle.com/datasets/kalilurrahman/nasdaq100-stock-price-data)

After downloading, place the data under the `data/` folder:

